function setup() {
    createCanvas(400,400);
}

function draw() {
  background(random(220), random(100), random(200));
  translate(width / 2, height / 2);
  let a = atan2(mouseY - height / 2, mouseX - width / 2);
  rotate(a);
  ellipse(-20, -10, 600, 10)
  
smooth();
ellipse(-100, 48, 36, 36);
noSmooth();
ellipse(100, 48, 36, 36);
}