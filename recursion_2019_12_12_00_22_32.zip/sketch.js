function setup() {
  createCanvas(800, 800);
 fill(93,193,185,50);
  strokeWeight(0);
}

function draw() {
  background(0,0,0);
  let niveles = round(map(mouseX, 0, width, 0, 4));
  recursiveCircle(width/2, height/2, 350, niveles);
}

function recursiveCircle(x, y, diam, levels){
  ellipse(x, y, diam);
  if(levels > 1){
    recursiveCircle(x-diam/2, y, diam/2, levels-1);
    recursiveCircle(x+diam/2, y, diam/2, levels-1);
    recursiveCircle(x, y-diam/4, diam/2, levels-1);
    recursiveCircle(x, y+diam/4, diam/2, levels-1);
  }
}