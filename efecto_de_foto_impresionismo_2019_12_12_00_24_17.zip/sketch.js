let pic;

function preload() {
  pic = loadImage('impresionismo-2-e1556911531220.jpg');
}
function setup() {
  createCanvas(pic.width, pic.height);
  noLoop();
}

let sp = 9;

function draw() {
  //background(pic); 
  stroke(255);
  noStroke()
  for (let y = 0; y < height; y += sp) {
    for (let x = 0; x < width; x += sp) {
      let col = pic.get(x, y);
      fill(col);
      rect(x, y, sp, sp)
    }
  }
}