function setup() {
  createCanvas(500, 500);
  cursor(CROSS);
}

function draw() {
  background(0);

  
  let numX = 13; 
  let numY = 13; 
  
  let m = 80;
  
  let spx = (width - 2*m)/(numX - 1);
  let spy = (height - 2*m)/(numY - 1);
  
  
  for (let y = 0; y < numY; y++) {
    for (let x = 0; x < numX; x++) {
      
     
      let d = dist(mouseX, mouseY, m + x*spx, m + y*spy);
      
      let r = map(d, 0, width, 0, PI);
      
      
      push();
      translate(m + x*spx, m + y*spy);
      rotate(r); 
      
      rotate(r); 
      triangle(30, 75, 58, 20, 86, 75);
      pop();
    }
  }
}