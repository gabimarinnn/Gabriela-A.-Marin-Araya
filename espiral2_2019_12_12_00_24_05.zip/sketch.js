function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}var angle = 0;
  var r =  100;

var spin = 0.5;
var grow = spin * 0.5;

function setup() {
  createCanvas(800, 800);
  background(0);
}

function draw() {
  angle += spin;
  r = r + grow;
  var x = cos(angle)*r;
  var y = sin(angle)*r;
  translate(400, 400);
  //line(0, 0, x, y);
  ellipse(x, y, 2, 2);





}