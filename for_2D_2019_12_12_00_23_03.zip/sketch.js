let max_distance;

function setup() {
  createCanvas(600,400);
  max_distance = dist(4, 4, width,height);
}

function draw() {
  background(0,100,150);

  for (let i = 0; i <= width; i += 20){
    for (let j = 0; j <= height; j += 1) {    
      let size = dist(mouseX, mouseY, i, j);
      size = (size / max_distance) * 25;
      rect(i, j, size, size);
      fill(50);
    }
  }
}
