var a = 0;
var r = 50;

function setup() {
  createCanvas(windowWidth, windowHeight);
  background(200,50,0);
  frameRate(15);
}

function draw() {
  noFill();
  translate(width , height );
  let a = atan2(mouseY - height , mouseX - width );
  rotate(a);

  var x = r * cos(a);
  var y = r * sin(a);

  a += 0.1;
  r += 1;

  push();
  translate(width / 2, height / 2);
  strokeWeight(2);
  stroke(255);
  ellipse(x, y, 50, 50);
  pop();
   
}