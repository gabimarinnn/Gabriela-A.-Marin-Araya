let pic,c;

function preload() {  
  pic = loadImage("parque.jpg");
  c = loadImage("perro6.png");              
}
function setup() {
    cursor("corazon.jpg"); // no aparece 
    createCanvas(600,400);
    background (pic);
    imageMode(CENTER);
    song = loadSound('perro.mp3');
}
function draw() {
    if (mouseIsPressed) {
  image(c, mouseX, mouseY, 100, 100); 
  }
}
function mousePressed() {
  if (song.isPlaying()) {
    
    
  } else {
    song.play();
   
  }
}

  
                