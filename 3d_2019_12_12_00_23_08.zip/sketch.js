let r = 10
let a = 0
let c = 20
let angle = 0
let art

function setup() {
  createCanvas(400, 400, WEBGL);
  art = createGraphics(400, 400)
  
}

function draw() {
  background(0);
    push()
  //translate(200, 200)
  let x = r + c * cos(a)

  let y = r + c * sin(a)

  art.fill(random(220), random(100), random(200));
  art.ellipse(x + 200, y + 200, 10, 10)

  c += 0.2
  a += 0.8
  pop()

  push()
  texture(art)
  rotateX(angle)
  rotateY(angle)
  rotateZ(angle)
  box(200)

  angle += 0.0003
  pop()


}
